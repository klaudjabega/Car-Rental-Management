package com.example.drivenimbus.model;

public enum MaintanceStatus {
    SCHEDULED,
    COMPLETED
}
