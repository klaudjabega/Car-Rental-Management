package com.example.drivenimbus.model;

public enum PayStatus {
    SUCCESS,
    FAILED
}
