package com.example.drivenimbus.model;

public enum State {
    AVAILABLE,
    BOOKED,
    MAINTENANCE
}
