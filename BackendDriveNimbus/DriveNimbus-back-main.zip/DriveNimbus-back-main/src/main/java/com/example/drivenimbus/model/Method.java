package com.example.drivenimbus.model;

public enum Method {
    CASH,
    CREDIT_CARD,
    DEBIT_CARD,
    PAYPAL,
}
