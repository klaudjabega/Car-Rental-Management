package com.example.drivenimbus.model;

public enum Role {
    ADMIN,
    USER
}
