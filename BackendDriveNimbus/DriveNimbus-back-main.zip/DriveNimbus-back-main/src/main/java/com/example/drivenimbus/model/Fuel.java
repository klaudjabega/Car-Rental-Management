package com.example.drivenimbus.model;

public enum Fuel {
    GASOLINE,
    DIESEL,
    ELECTRIC,
    PETROL
}
