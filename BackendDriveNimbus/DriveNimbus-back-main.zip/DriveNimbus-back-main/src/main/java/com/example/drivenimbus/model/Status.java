package com.example.drivenimbus.model;

public enum Status {
    PENDING,
    CONFIRMED,
    CANCELLED,
    REJECTED
}
